 This package includes source codes of our TEGS approach, which predicting essential protein by integrating network topology, subcellular localization information, gene expression profile and GO annotation data.
Originally: Developed by Wei Zhang, School of Science,East China Jiaotong University, Data:  05/2018, Contact:wzhang_math@whu.edu.cn

Please kindly cite the following papers.
Wei Zhang, Jia Xu, and Xiufen Zou,"Predicting essential proteins by integrating network topology, subcellular localization information, gene expression profile and GO annotation data",IEEE/ACM TRANSACTIONS ON COMPUTATIONAL BIOLOGY AND BIOINFORMATICS.

The package is for academic use only.


