function TEGS_METHOD_identifying_essential_proteins_main1
%% This is a matlab impolementation of the paper titled as: "Predicting essential proteins by integrating network topology, subcellular localization information, gene expression profile and GO annotation data"
% Originally: Developed by Wei Zhang, School of Science,East China Jiaotong University,
% Data:  05/2018, Contact:wzhang_math@whu.edu.cn


% addpath(genpath('./')) %

clc;clear;
addpath('data')

%   dataname='DIP_PPI_5093';
  dataname='krogan2006_extended_PPI_3672';


% GOsim=importdata(strcat('GO_semanticsim_value_', dataname,'.mat'));

[~, PPI_inter_str] = xlsread(strcat(dataname,'.xlsx'));
protein_total=unique(PPI_inter_str(:));

n=size(PPI_inter_str,1);  % number of interaction
n1=size(protein_total,1);
PPI_inter_num=zeros(2,n);  %% interaction number
for i=1:n
    flag=0;
    for j=1:n1
        if strcmp(PPI_inter_str(i,1),protein_total(j))  % 
            PPI_inter_num(1,i)=j;
            flag=flag+1;
        end
        if strcmp(PPI_inter_str(i,2),protein_total(j)) % 
            PPI_inter_num(2,i)=j;
            flag=flag+1;
        end
        if flag==2
            break;
        end
    end
end
save PPI_inter_num.mat PPI_inter_num

%
adj=zeros(n1,n1);
for i=1:n
    adj(PPI_inter_num(1,i),PPI_inter_num(2,i))=1;
end
adj=max(adj,adj');
save adj.mat adj
%
[exp_data, protein_name] = xlsread('experimental_data.xlsx');

% degree
d_gree=sum(adj,1);
%% compute edge cluster coefficient and PCC coefficient of protein pairs
edge_clustercoefficient=zeros(length(PPI_inter_num),1);
PCC_coeff=zeros(length(PPI_inter_num),1);
for j=1:length(PPI_inter_num)
    node_a=PPI_inter_num(1,j);
    node_b=PPI_inter_num(2,j);
    %% 
    index1=find(adj(node_a,:));
    index2=find(adj(node_b,:));
    comm_index=intersect(index1,index2);
    if d_gree(node_a)==1 || d_gree(node_b)==1
        edge_clustercoefficient(j)=0;
    else
        edge_clustercoefficient(j)=length(comm_index)/min(d_gree(node_a)-1,d_gree(node_b)-1); %
    end
    index_1=find(strcmp(protein_total{node_a},protein_name));
    index_2=find(strcmp(protein_total{node_b},protein_name));
    if isempty(index_1) || isempty(index_2)
        PCC_coeff(j)=0;
    else
        PCC_coeff(j)=PCC(exp_data(index_1,:),exp_data(index_2,:));
    end
end
save edge_clustercoefficient.mat edge_clustercoefficient
save PCC_coeff.mat PCC_coeff

% collect and compute the subcellular localization information
%%  subcellular localization data ---knowledge channel of compartments database--2018-4-9
[~, bstrings] = xlsread('yeast_compartment_knowledge_full.xlsx');
subcell_info={'Cytoskeleton','Golgi apparatus','Cytosol','Endosome','Mitochondrion','Plasma membrane','Nucleus','Extracellular space','Vacuole','Endoplasmic reticulum','Peroxisome'};
% save subcell_info.mat subcell_info
%% 
[aa0 bb0]=ismember(bstrings(:,4),subcell_info);
[cc dd]=find(aa0==1);
datasubcell=bstrings(cc,:);  %

[~, protein_essential] = xlsread('known_essential_proteins.xlsx');
protein_essential=intersect(protein_essential,protein_total);
%%��

index_multi={}; k1=1;  %% 
index_single=[]; k2=1;  %%
for i=1:length(protein_essential)
    protein_i=protein_essential{i};
    [c0 temp_num]=find(strcmp(protein_i,datasubcell(:,1))); %% 
    if c0~=0
        subcellular_info=datasubcell(c0,4); %% 
        [aa bb]=ismember(subcellular_info,subcell_info); %% 
        if length(unique(bb))>1
            index_multi{k1}=unique(bb);
            k1=k1+1;
        else
            index_single(k2)=unique(bb);
            k2=k2+1;
        end
    else
        index_single(k2)=0;
        k2=k2+1;
    end
end
% save  index_single.mat index_single
% save  index_multi.mat  index_multi

%% collect the statistical information
TABLE_botk= tabulate(index_single);
% save TABLE_botk.mat TABLE_botk
%%
num_frequent=TABLE_botk(2:end,2);   %% obtain the collect number
num_S=sum(num_frequent);
subcellular_frequent=TABLE_botk(:,2)/num_S; %% collect the frequent of certain subcellular appeared
% save subcellular_frequent.mat subcellular_frequent
%% 
% SL
SL_score=zeros(length(protein_total),1);
for i=1:length(protein_total)
    protein_a=protein_total{i};
    [c0 temp_num]=find(strcmp(protein_a,datasubcell(:,1)));
    if c0~=0
        subcellular_info=datasubcell(c0,4); %% obtain subcellular localization information
        [aa bb]=ismember(subcellular_info,subcell_info);
        subcellular_index_appear=unique(bb);
        [index_logic index_1]=ismember(subcellular_index_appear,TABLE_botk(:,1));
        index_1=index_1(find(index_1));  % filter the o element
        data_c=subcellular_frequent(index_1);
        SL_score(i)=sum(data_c);
    end
end
save SL_score.mat SL_score

Protein_subcellular_loc={};
k=1;
for i=1:length(protein_total)
    protein_i=protein_total{i};
    [c0 index_num]=find(strcmp(protein_i,datasubcell(:,1))); %% 
    if c0~=0
        subcellular_info=datasubcell(c0,4); %% 
        [aa bb]=ismember(subcellular_info,subcell_info); %% obtain the subcellular location index number
        Protein_subcellular_loc{k}=unique(bb);
        k=k+1;
    else
        Protein_subcellular_loc{k}=0;  %%
        k=k+1;
    end
end
save Protein_subcellular_loc.mat Protein_subcellular_loc


% SL_score=importdata('SL_score.mat');
% Protein_subcellular_loc=importdata('Protein_subcellular_loc.mat');
% adj=importdata('adj.mat');
% PPI_inter_num=importdata('PPI_inter_num.mat');
% edge_clustercoefficient=importdata('edge_clustercoefficient.mat');
% PCC_coeff=importdata('PCC_coeff.mat');

%% load the GO semantic similarity result
% GOsim=importdata('GO_semanticsim_value_DIP_PPI_5093.mat');
GOsim=importdata(strcat('GO_semanticsim_value_', dataname,'.mat'));
%{
%% TEGS method
TEGS_value=zeros(length(adj),1);
alpha=0.2;
for i=1:length(adj)
    node_neighbor=find(adj(i,:));
    sum_temp=0;
    for j=1:length(node_neighbor)  % �ҳ��ھӽڵ㼯��
        node_a=i; node_b=node_neighbor(j);
        index1=find(PPI_inter_num(1,:)==node_a); index11=find(PPI_inter_num(2,:)==node_b);
        index_1=intersect(index1,index11);
        index2=find(PPI_inter_num(1,:)==node_b); index22=find(PPI_inter_num(2,:)==node_a);
        index_2=intersect(index2,index22);
        SL_infor_a=Protein_subcellular_loc{node_a};
        SL_infor_b=Protein_subcellular_loc{node_b};
        if ~isempty(SL_infor_a) && ~isempty(SL_infor_b)
            comm=intersect(SL_infor_a,SL_infor_b);
            if sum(comm)>=1
                comm=setdiff(comm,0);
                PPI_SL_infor=length(comm); %% 
            else
                PPI_SL_infor=0;
            end
        end
        if index_1>0
            sum_temp=sum_temp+edge_clustercoefficient(index_1)* PPI_SL_infor*(PCC_coeff(index_1)+GOsim(index_1));
        else
            sum_temp=sum_temp+edge_clustercoefficient(index_2)* PPI_SL_infor*(PCC_coeff(index_2)+GOsim(index_2));
        end
    end
    TEGS_value(i)=alpha*sum_temp+(1-alpha)*SL_score(i);  %
end
[sum_temp1, index]=sort(TEGS_value,'descend'); %% 
Ranked_genes=protein_total(index); %%��
common_gene=[];
for num=1:1:6
    common_gene(num)=length(intersect(protein_essential,Ranked_genes(100*(num-1)+1:num*100)));
end
num_predicted_essential=cumsum(common_gene);
num_predicted_essential=num_predicted_essential';
xlswrite([dataname,'_num_essential_proteins_predict_TEGS_top600'  '.xlsx'],num_predicted_essential)
%}

%% TEGS method
TEGS_value=zeros(length(adj),1);
for alpha=0:0.1:1
    for i=1:length(adj)
        node_neighbor=find(adj(i,:));
        sum_temp=0;
        for j=1:length(node_neighbor)  % �ҳ��ھӽڵ㼯��
            node_a=i; node_b=node_neighbor(j);
            index1=find(PPI_inter_num(1,:)==node_a); index11=find(PPI_inter_num(2,:)==node_b);
            index_1=intersect(index1,index11);
            index2=find(PPI_inter_num(1,:)==node_b); index22=find(PPI_inter_num(2,:)==node_a);
            index_2=intersect(index2,index22);
            SL_infor_a=Protein_subcellular_loc{node_a};
            SL_infor_b=Protein_subcellular_loc{node_b};
            if ~isempty(SL_infor_a) && ~isempty(SL_infor_b)
                comm=intersect(SL_infor_a,SL_infor_b);
                if sum(comm)>=1
                    comm=setdiff(comm,0);
                    PPI_SL_infor=length(comm); %% ���ڹ�ͬϸ��λ�ø���
                else
                    PPI_SL_infor=0;
                end
            end
            if index_1>0
                sum_temp=sum_temp+edge_clustercoefficient(index_1)* PPI_SL_infor*(PCC_coeff(index_1)+GOsim(index_1));
            else
                sum_temp=sum_temp+edge_clustercoefficient(index_2)* PPI_SL_infor*(PCC_coeff(index_2)+GOsim(index_2));
            end
        end
        TEGS_value(i)=alpha*sum_temp+(1-alpha)*SL_score(i);  %
    end
    save(['PPI_unsort_essential_TEGS_proteins_for_parameter_alpha_' num2str(alpha) '.mat'],'TEGS_value');
    %     [sum_temp1, index]=sort(TEGS_rank,'descend'); %% ����ָ����н�������
    %     gene_sort=protein_total(index); %%������ԭ����������
    %     xlswrite(['PPI_sort_essential_TEGS_new_proteins_for_parameter_alpha_' num2str(alpha) '.xlsx'],[gene_sort(:),num2cell(sum_temp1)])
end
%  save(['PPI_unsort_essential_P_proteins_for_parameter_alpha_' num2str(alpha) '.mat'],'TEGS_rank');


kk=1;
collect_num_predicted_essential=[];
for alpha=0:0.1:1
    s=strcat('PPI_unsort_essential_TEGS_proteins_for_parameter_alpha_', num2str(alpha)); % �ڶ���ʱ��������
    [TEGS_value, ~]=importdata(strcat(s,'.mat'));
    [sum_temp1, index]=sort(TEGS_value,'descend'); %% ����ָ����н�������
    Ranked_genes=protein_total(index); %%������ԭ����������
    common_gene=[];
    for num=1:1:6
        common_gene(num)=length(intersect(protein_essential,Ranked_genes(100*(num-1)+1:num*100)));
    end
    num_predicted_essential=cumsum(common_gene);
    num_predicted_essential=num_predicted_essential';
    collect_num_predicted_essential(:,kk)=num_predicted_essential;
    kk=kk+1;
end
xlswrite([dataname,'_num_predicted_essential_proteins_TEGS_top600_all'  '.xlsx'],collect_num_predicted_essential)


%% select the best parameter t to obtain the best results
t=0.2;
s=strcat('PPI_unsort_essential_TEGS_proteins_for_parameter_alpha_', num2str(t)); % �ڶ���ʱ��������
[TEGS_value, ~]=importdata(strcat(s,'.mat'));
[sum_temp1, index]=sort(TEGS_value,'descend'); %% ����ָ����н�������
Ranked_genes=protein_total(index); %%������ԭ����������
common_gene=[];
for num=1:1:6
    common_gene(num)=length(intersect(protein_essential,Ranked_genes(100*(num-1)+1:num*100)));
end
num_predicted_essential=cumsum(common_gene);
num_predicted_essential=num_predicted_essential';
xlswrite([dataname,'_num_essential_proteins_predict_TEGS_top600'  '.xlsx'],num_predicted_essential)

%%
% common_gene=[];
% for num=1:1:1000
%     common_gene(num)=length(intersect(protein_essential,Ranked_genes(2*(num-1)+1:num*2)));
% end
% cnum_predicted_essential_TEGS=cumsum(common_gene);
% save cnum_predicted_essential_TEGS_method.mat cnum_predicted_essential_TEGS
% 
% figure
% a=1:20:1000;
% bb=1:10:500;
% plot(a,cnum_predicted_essential_TEGS(bb),'r.-', 'MarkerSize',14,'LineWidth',2)
% legend('TEGS','location','SouthEast');
% xlabel('The number of top ranked proteins','FontWeight','Bold','FontSize',12)
% ylabel('The cumulative count of essential proteins','FontWeight','Bold','FontSize',12)
% set(gca,'FontWeight','Bold','FontSize',12)
% ylim([0 550])
% saveas(gcf,'plot_cumulative_number_essential_protein_TEGS.pdf')



function result=PCC(a,b)
result=0;
n=length(a);
a_m=mean(a);
b_m=mean(b);
for i=1:n
    result=result+((a(i)-a_m)/std(a))*((b(i)-b_m)/std(b));
end
result=result/(n-1);





%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%
%% GO  P term
collect=importdata('PPI_sgdgenes_P_GOinteraction_missed_collect.mat');
aaa=1:1:n;
bb=setdiff(aaa,collect);
[anumbers, astrings] = xlsread('PPI_go_interaction_sim_result_P.xlsx');
result_P=zeros(1,n);
result_P(bb)=anumbers(:,2);
result_P(collect)=0;
result_P=result_P';
aa=isnan(result_P);
bb=find(aa==1);
result_P(bb)=0;
disp('GO ���ݲ���')
save PPI_go_interaction_sim_result_P_total.mat result_P
%}






